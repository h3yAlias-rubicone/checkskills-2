/*
 * «Факториал»
 *
 * Напишите функцию factorial(n), возвращающую факториал неотрицательного
 * целого числа. Факториал — это произведение всех натуральных чисел
 * от 1 до n включительно. Факториал 0 равен 1.
 *
*/

function factorial(n) {
}

// Протестируйте решение, вызывая функцию с разными аргументами:

console.log(factorial(-5)); // cancel - return false
console.log(factorial('a')); // cancel - return false
console.log(factorial(5.5)); // cancel - return false

console.log(factorial(0)); // 1
console.log(factorial(1)); // 1
console.log(factorial(6)); // 720
